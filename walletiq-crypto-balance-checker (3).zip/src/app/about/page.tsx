import Navbar from '@/components/Navbar';
import Link from 'next/link';

export const metadata = {
  title: 'About WalletIQ - Our Story',
  description: 'Learn about WalletIQ, the privacy-first crypto wallet explorer launched in 2026.',
};

export default function AboutPage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-4xl mx-auto space-y-8">
          {/* Back Button */}
          <Link 
            href="/"
            className="inline-flex items-center gap-2 text-[#f7931a] hover:text-[#e8870f] transition-colors group"
          >
            <span className="text-xl group-hover:-translate-x-1 transition-transform">←</span>
            <span className="font-semibold">Back to Home</span>
          </Link>

          {/* Hero Section */}
          <div className="card text-center animate-fade-in">
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-[#f7931a] via-[#ffa500] to-[#f7931a] bg-clip-text text-transparent mb-4">
              About WalletIQ
            </h1>
            <div className="w-24 h-1 bg-gradient-to-r from-transparent via-[#f7931a] to-transparent mx-auto"></div>
          </div>

          {/* Timeline Section */}
          <div className="space-y-6">
            {/* 2026 Launch */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#f7931a] to-orange-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    🚀
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">2026 – WalletIQ Launched</h2>
                  <p className="text-slate-300 leading-relaxed">
                    WalletIQ was launched in early 2026 as a revolutionary, privacy-first crypto wallet explorer. From day one, it empowered users to instantly check live balances and transactions on multiple blockchain networks—without ever requiring logins, accounts, or personal data.
                  </p>
                </div>
              </div>
            </div>

            {/* Core Features */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    ⚡
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">In 2026 – Core Features Introduced</h2>
                  <p className="text-slate-300 leading-relaxed">
                    Right from the start, WalletIQ supported top cryptocurrencies like Bitcoin (BTC), Ethereum (ETH), BNB Smart Chain (BNB), Solana (SOL), and USDT (TRC20). Users simply selected their crypto, pasted a wallet address, and instantly accessed live balances and transactions—no registrations, no personal data required.
                  </p>
                </div>
              </div>
            </div>

            {/* Privacy Foundation */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-green-500 to-teal-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    🔒
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">Privacy as a Foundation</h2>
                  <p className="text-slate-300 leading-relaxed">
                    WalletIQ was built on a foundation of privacy. Unlike traditional apps, we never required logins or saved any wallet information. Every search was executed in real-time using public blockchain data—ensuring complete user control.
                  </p>
                </div>
              </div>
            </div>

            {/* 2027 Expansion */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-purple-500 to-pink-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    🌐
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">2027 – Multi-Network Expansion</h2>
                  <p className="text-slate-300 leading-relaxed">
                    By 2027, we expanded beyond Bitcoin, adding support for Ethereum, Solana, BNB, and TRC20 tokens. Users could now seamlessly check balances across multiple chains, all within a single interface.
                  </p>
                </div>
              </div>
            </div>

            {/* Speed */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-yellow-500 to-orange-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    ⚡
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">Speed and Real-Time Data</h2>
                  <p className="text-slate-300 leading-relaxed">
                    WalletIQ prioritized speed. Every balance check was lightning-fast, no caching—just live blockchain data streamed from trusted providers, so users always saw the most up-to-date info.
                  </p>
                </div>
              </div>
            </div>

            {/* Beyond Balances */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-indigo-500 to-blue-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    📊
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">Beyond Balances</h2>
                  <p className="text-slate-300 leading-relaxed">
                    WalletIQ grew into a comprehensive multi-chain tracker. Beyond simple balance checks, users could explore transaction histories, see confirmed and pending transfers, and even share wallet info via QR codes.
                  </p>
                </div>
              </div>
            </div>

            {/* Privacy and Safety */}
            <div className="card hover:shadow-xl transition-all duration-300 hover:scale-[1.01] group">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-2xl font-bold shadow-lg group-hover:scale-110 transition-transform">
                    🛡️
                  </div>
                </div>
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-[#f7931a] mb-2">Privacy and Safety</h2>
                  <p className="text-slate-300 leading-relaxed">
                    At WalletIQ, privacy remained a guiding principle. We never logged wallet addresses, never stored user searches—ensuring every user search was purely on-chain, fully private.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Mission Today */}
          <div className="card bg-gradient-to-br from-[#f7931a]/10 to-orange-900/10 border-2 border-[#f7931a]/30 hover:shadow-xl hover:shadow-[#f7931a]/20 transition-all duration-300">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="text-4xl">🎯</span>
                <h2 className="text-3xl font-bold text-[#f7931a]">Our Mission Today</h2>
              </div>
              <p className="text-lg text-slate-300 leading-relaxed">
                Today, WalletIQ stands as a premier, fast, and privacy-focused blockchain explorer. Our mission is simple: empower anyone, anywhere, to instantly explore their crypto wallets, with speed, trust, and privacy at the core.
              </p>
            </div>
          </div>

          {/* Disclaimers */}
          <div className="card border-2 border-yellow-500/30 bg-gradient-to-br from-yellow-900/20 to-red-900/20 hover:shadow-xl hover:shadow-yellow-500/10 transition-all duration-300">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <span className="text-4xl">⚠️</span>
                <h2 className="text-2xl font-bold text-yellow-400">Important Notice</h2>
              </div>
              <div className="space-y-2 text-slate-300 pl-6">
                <div className="flex items-start gap-3">
                  <span className="text-red-400 text-xl">✗</span>
                  <p>We do not offer investment schemes.</p>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-red-400 text-xl">✗</span>
                  <p>We do not provide asset recovery services.</p>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-red-400 text-xl">✗</span>
                  <p>We never ask for access to your funds.</p>
                </div>
                <div className="flex items-start gap-3">
                  <span className="text-green-400 text-xl">✓</span>
                  <p className="font-semibold text-green-400">
                    Stay safe and always verify wallet addresses before sending crypto.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Call to Action */}
          <div className="card text-center bg-gradient-to-r from-[#f7931a]/5 to-orange-900/5 border border-[#f7931a]/20">
            <h3 className="text-2xl font-bold text-[#f7931a] mb-4">Ready to Explore?</h3>
            <p className="text-slate-300 mb-6">
              Start checking your crypto wallet balances instantly
            </p>
            <Link 
              href="/"
              className="btn-primary inline-block"
            >
              Check Wallet Now
            </Link>
          </div>

          {/* Footer */}
          <div className="text-center text-sm text-slate-500 pb-12">
            <p>WalletIQ does not store wallet addresses. All lookups are temporary and private.</p>
          </div>
        </div>
      </main>
    </div>
  );
}
