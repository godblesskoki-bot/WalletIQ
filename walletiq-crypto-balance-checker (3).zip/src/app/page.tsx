import Navbar from '@/components/Navbar';
import WalletSearch from '@/components/WalletSearch';
import PremiumInfoSection from '@/components/PremiumInfoSection';
import BitcoinPriceBar from '@/components/BitcoinPriceBar';

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12">
        <div className="flex flex-col items-center space-y-12">
          {/* Hero Section */}
          <div className="text-center space-y-4">
            <h1 className="text-5xl md:text-6xl font-bold text-[#f7931a] mb-2">
              WalletIQ
            </h1>
            <p className="text-xl text-slate-400">
              Check your crypto wallet balances across multiple blockchains
            </p>
          </div>

          {/* Search Section */}
          <WalletSearch />

          {/* Premium Info Section - New! */}
          <div className="w-full mt-16">
            <PremiumInfoSection />
          </div>

          {/* Bitcoin Price Section */}
          <div className="w-full max-w-md mt-12">
            <BitcoinPriceBar />
          </div>

          {/* About Button */}
          <div className="w-full max-w-md mt-6">
            <a 
              href="/about"
              className="card text-center hover:shadow-xl hover:scale-105 transition-all duration-300 group cursor-pointer block"
            >
              <div className="flex items-center justify-center gap-3">
                <span className="text-3xl group-hover:scale-110 transition-transform">ℹ️</span>
                <span className="text-xl font-bold text-[#f7931a] group-hover:text-[#e8870f] transition-colors">
                  About WalletIQ
                </span>
                <span className="text-[#f7931a] group-hover:translate-x-1 transition-transform">→</span>
              </div>
            </a>
          </div>

          {/* Footer */}
          <footer className="text-center text-sm text-slate-500 mt-16">
            <p>WalletIQ does not store wallet addresses. All lookups are temporary and private.</p>
          </footer>
        </div>
      </main>
    </div>
  );
}
