'use client';

import { useState, useEffect } from 'react';
import Navbar from '@/components/Navbar';
import WalletSearch from '@/components/WalletSearch';
import PriceChartComponent from '@/components/PriceChartComponent';
import CryptoCalculator from '@/components/CryptoCalculator';
import BitcoinPriceBar from '@/components/BitcoinPriceBar';
import { getCryptoPrices, CRYPTO_IDS, getMarketChart } from '@/lib/api';

const PERIODS = [
  { label: '1 Day', value: 1 },
  { label: '5 Days', value: 5 },
  { label: '1 Month', value: 30 },
  { label: '1 Year', value: 365 },
  { label: '5 Years', value: 1825 },
  { label: 'Max', value: 'max' },
];

const CRYPTOS = [
  { label: 'Bitcoin', value: 'BTC' },
  { label: 'Ethereum', value: 'ETH' },
  { label: 'Solana', value: 'SOL' },
  { label: 'Binance Coin', value: 'BNB' },
  { label: 'USDT', value: 'USDT' },
];

export default function PriceChartPage() {
  const [selectedCrypto, setSelectedCrypto] = useState('BTC');
  const [selectedPeriod, setSelectedPeriod] = useState(30);
  const [currentPrice, setCurrentPrice] = useState(0);
  const [periodChange, setPeriodChange] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchPriceData = async () => {
      setLoading(true);
      try {
        const cryptoId = CRYPTO_IDS[selectedCrypto];
        const [prices, chartData] = await Promise.all([
          getCryptoPrices([cryptoId]),
          getMarketChart(cryptoId, selectedPeriod),
        ]);

        const price = prices[cryptoId].usd;
        setCurrentPrice(price);

        // Calculate period change
        if (chartData.prices && chartData.prices.length > 0) {
          const oldPrice = chartData.prices[0][1];
          const newPrice = chartData.prices[chartData.prices.length - 1][1];
          const change = ((newPrice - oldPrice) / oldPrice) * 100;
          setPeriodChange(change);
        }
      } catch (error) {
        console.error('Error fetching price data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchPriceData();
  }, [selectedCrypto, selectedPeriod]);

  return (
    <div className="min-h-screen">
      <Navbar />
      
      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto space-y-8">
          <WalletSearch />

          {/* Price Header */}
          <div className="card">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <h2 className="text-xl text-slate-400 mb-2">
                  {CRYPTOS.find(c => c.value === selectedCrypto)?.label} Price
                </h2>
                <p className="text-4xl font-bold text-[#f7931a]">
                  {loading ? 'Loading...' : `$${currentPrice.toLocaleString()}`}
                </p>
              </div>
              <div className="flex gap-4 items-center">
                <div>
                  <p className="text-sm text-slate-400 mb-1">Period Change</p>
                  <p className={`text-2xl font-bold ${periodChange >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {loading ? '...' : `${periodChange >= 0 ? '+' : ''}${periodChange.toFixed(2)}%`}
                  </p>
                </div>
                <select
                  value={selectedPeriod}
                  onChange={(e) => setSelectedPeriod(Number(e.target.value) || e.target.value as any)}
                  className="input-field"
                >
                  {PERIODS.map((period) => (
                    <option key={period.label} value={period.value} className="bg-slate-800">
                      {period.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Crypto Selector */}
          <div className="card">
            <h3 className="text-xl font-semibold mb-4">Select Cryptocurrency</h3>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {CRYPTOS.map((crypto) => (
                <button
                  key={crypto.value}
                  onClick={() => setSelectedCrypto(crypto.value)}
                  className={`py-3 px-4 rounded-xl font-semibold transition-all ${
                    selectedCrypto === crypto.value
                      ? 'bg-[#f7931a] text-white'
                      : 'bg-slate-700/50 text-slate-300 hover:bg-slate-700'
                  }`}
                >
                  {crypto.label}
                </button>
              ))}
            </div>
          </div>

          {/* Chart */}
          <div>
            <h2 className="text-2xl font-bold mb-4 text-[#f7931a]">
              {selectedCrypto} / USD
            </h2>
            <PriceChartComponent
              cryptoId={CRYPTO_IDS[selectedCrypto]}
              days={selectedPeriod}
            />
          </div>

          {/* Calculator */}
          <CryptoCalculator crypto={selectedCrypto} price={currentPrice} />

          {/* Bitcoin Price */}
          <div className="w-full max-w-md mx-auto">
            <BitcoinPriceBar />
          </div>

          <footer className="text-center text-sm text-slate-500 mt-16">
            <p>WalletIQ does not store wallet addresses. All lookups are temporary and private.</p>
          </footer>
        </div>
      </main>
    </div>
  );
}
