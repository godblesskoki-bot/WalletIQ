# WalletIQ - Crypto Wallet Balance Checker

A modern, privacy-focused crypto wallet balance checker built with Next.js that supports multiple blockchains.

## 🚀 Features

- **Multi-Chain Support**: Bitcoin (BTC), Ethereum (ETH), Solana (SOL), Binance Coin (BNB), and USDT TRC20
- **Live Price Data**: Real-time cryptocurrency prices from CoinGecko
- **Interactive Charts**: Historical price charts with multiple time periods
- **QR Code Generation**: Generate QR codes for wallet addresses
- **Transaction History**: View recent transactions with USD conversions
- **Crypto Calculator**: Convert between crypto and USD values
- **Privacy-First**: No data storage, localStorage, cookies, or backend - all lookups are temporary and private
- **Modern Dark UI**: Sleek Web3-style design with Bitcoin orange accents

## 🛠️ Tech Stack

- **Next.js 16** (App Router)
- **TypeScript**
- **Tailwind CSS**
- **Axios** for API calls
- **Recharts** for price charts
- **QRCode.react** for QR code generation

## 📡 APIs Used

- **CoinGecko API** - Cryptocurrency prices and market data
- **Blockstream API** - Bitcoin wallet data
- **Etherscan API** - Ethereum wallet data
- **BscScan API** - Binance Smart Chain wallet data
- **Solana RPC** - Solana wallet data
- **TronGrid API** - USDT TRC20 wallet data

## 🔒 Privacy

WalletIQ is designed with privacy in mind:
- ✅ No backend server
- ✅ No database
- ✅ No localStorage
- ✅ No cookies
- ✅ No data persistence
- ✅ All wallet lookups are temporary and fetched live from APIs

## 🎨 Pages

- **Home (/)** - Search for wallet addresses
- **Wallet (/wallet)** - View wallet balance, transactions, and QR code
- **Price Chart (/price-chart)** - Interactive price charts with crypto calculator

## 🚀 Getting Started

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Open [http://localhost:3000](http://localhost:3000) in your browser

## 📝 Environment Variables (Optional)

For better API rate limits, you can add:

```env
NEXT_PUBLIC_ETHERSCAN_API_KEY=your_etherscan_api_key
NEXT_PUBLIC_BSCSCAN_API_KEY=your_bscscan_api_key
```

Note: The app works without these keys using public endpoints.

## 🏗️ Build for Production

```bash
npm run build
npm start
```

## 📱 Responsive Design

The app is fully responsive and works seamlessly on:
- Desktop
- Tablet
- Mobile

## 🎯 Design Features

- Dark gradient background (slate-900 to black)
- Glass-morphism cards
- Bitcoin orange (#f7931a) accent color
- Smooth hover transitions
- Clean spacing and typography
- Professional dashboard layout

---

Built with ❤️ using Next.js
